README.txt

498hw9_report.pdf is out report.

Part I MNIST
mnist.zip contains mnist-original.py & mnist-improved.py, which are code for original and modified convolutional neural netowrk(CNN) for MNIST problem, respectively. The log file is saved in mnist_original/test and mnist_original/train.

MNIST-original.png and MNIST-improved.png are screenshots of tensorboard for original and modified CNN for MNIST, respectively.

Part II CIFAR10
cifar10.zip contains codes for cifar10 model. We train and evaluate the model using cifar10_train_eval.py. The log file for test accuracy is saved in cifar/.

CIFAR10.png is the screenshot of tensorboard for original for CIFAR10.

group_file.txt is our group information.